package com.example.mortgagecalculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class CalcMortgage extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //get the intent sent from the fragment, extract bundle
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        //extract the values from the bundle
        int price = bundle.getInt("price");
        double interest = bundle.getDouble("interest");
        int numMonths = bundle.getInt("months");

        //send values to emi method to calculate emi
        double results = emi(price, interest, numMonths);
        DecimalFormat df = new DecimalFormat("#.##");

        //set content view to this activity, display results
        setContentView(R.layout.calc_mortgage);
        TextView mortgageValue = (TextView)findViewById(R.id.result);
        mortgageValue.setText("$" + df.format(results));

        //button to close the activity and return to main screen
        Button button = (Button) findViewById(R.id.buttonR);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    //calculate the EMI
    private double emi(int price, double interest, int months){
        //need to find the equivalent interest rate
        double intr = (Math.pow((1+(interest/200)),(2.0/12.0))-1);
        //calculate emi using equivalent interest rate
        double numerator = Math.pow((1 + intr),months);
        numerator = intr*numerator*price;
        double denominator = Math.pow((1+intr), months);
        denominator = denominator-1;

        double results = numerator/denominator;

        return results;
    }

}
