package com.example.mortgagecalculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class CalcMortgage extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //get the intent sent from the fragment
        Intent intent = getIntent();
        //extract the bundle from the intent
        Bundle bundle = intent.getExtras();
        //extract the values from the bundle
        int price = bundle.getInt("price");
        double interest = bundle.getDouble("interest");
        int numMonths = bundle.getInt("months");

        //send values to emi method to calculate emi
        double results = emi(price, interest, numMonths);
        //format to two decimal places
        DecimalFormat df = new DecimalFormat("#.##");

        //set the viewed content to this activity
        setContentView(R.layout.calc_mortgage);
        //obtain the TextView the result will be shown in
        TextView mortgageValue = (TextView)findViewById(R.id.result);
        //set the text to the result
        mortgageValue.setText("$" + df.format(results));

        //Button to close the activity and return to main screen
        Button button = (Button) findViewById(R.id.buttonR);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }


    private double emi(int price, double interest, int months){
        double intr = (interest/100)/12;

        double numerator = Math.pow((1 + intr),months);
        numerator = intr*numerator*price;
        double denominator = Math.pow((1+intr), months);
        denominator = denominator-1;

        double results = numerator/denominator;


        return results;
    }

}
