package com.example.mortgagecalculator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.app.AlertDialog;
import android.content.DialogInterface;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.mortgagecalculator.databinding.FragmentFirstBinding;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //Setting up alerts for error checking (missing values)
        AlertDialog.Builder alert = new AlertDialog.Builder(view.getContext());
        alert.setNegativeButton(
                "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        binding.calcButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(binding.principleValue.getText().toString())){
                    //if Mortgage Principle Amount is empty
                    alert.setMessage("Requires Mortgage Price");
                    alert.setCancelable(true);
                    alert.show();
                }else if(TextUtils.isEmpty(binding.interestValue.getText().toString())){
                    //if Interest Rate is empty
                    alert.setMessage("Requires Interest Rate");
                    alert.setCancelable(true);
                    alert.show();
                }else if(TextUtils.isEmpty(binding.numMonths.getText().toString())){
                    //if Number of Months is empty
                    alert.setMessage("Requires Number of Months");
                    alert.setCancelable(true);
                    alert.show();
                }else{
                    //if all EditText have values, get those values
                    int price = Integer.parseInt(binding.principleValue.getText().toString());
                    double interest = Double.parseDouble(binding.interestValue.getText().toString());
                    int numMonths = Integer.parseInt(binding.numMonths.getText().toString());

                    //create intent and bundle
                    Intent calculate = new Intent(getActivity(), CalcMortgage.class);
                    Bundle b = new Bundle();
                    //add all values to the bundle
                    b.putInt("price", price);
                    b.putDouble("interest", interest);
                    b.putInt("months", numMonths);
                    //put bundle in intent
                    calculate.putExtras(b);
                    //send the intent, start the CalcMortgage activity
                    startActivity(calculate);

                    //clears the EditText
                    binding.principleValue.setText("");
                    binding.interestValue.setText("");
                    binding.numMonths.setText("");
                }

            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}